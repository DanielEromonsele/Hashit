import React from "react";
import { styled } from "styled-components";
import GlobalButton from "./GlobalButton";
import {useState, useEffect, useRef} from "react"


const Hero =()=>{

  const [days, setDays] = useState(0)
  const [hours, setHours] = useState(0)
  const [minutes, setMinutes] = useState(0)
  const [seconds, setSeconds] = useState(0)


  useEffect(() =>{
    const target = new Date("09/8/2023  11:59:59" )

    const interval = setInterval(()=>{
      const now = new Date()
      const difference = target.getTime() - now.getTime()  

      const d = Math.floor(difference / (1000 * 60 * 60 * 24))
      setDays(d)

      const h = Math.floor((difference % (1000 * 60 * 60 * 24) / (1000 * 60 * 60)))
      setHours(h)

      const m = Math.floor((difference % (1000 * 60 * 60 ) / (1000 * 60 )))
      setMinutes(m)

      const s = Math.floor((difference % (1000 * 60 ) / (1000)))
      setSeconds(s)
    }, 1000)

    return () => clearInterval(interval)
  }, [])
 
  const Dev: string[] = [
    "background-image: linear-gradient(to right, #007cf0, #00dfd8); background-clip: text; -webkit-background-clip: text; -webkit-text-fill-color: transparent",
    "white",
    "white" 
  ]
  const Prev: string[] = [
    "white",
    "background-image: linear-gradient(to right, #7928ca,  #ff0080); background-clip: text; -webkit-background-clip: text; -webkit-text-fill-color: transparent",
    "white"
  ]
  const Shi: string[] = [
    "white",
    "white",
    "background-image: linear-gradient(to right, #ff4d4d, #f9cb28); background-clip: text; -webkit-background-clip: text; -webkit-text-fill-color: transparent",
  ]

  let Dev_ref: any = useRef()
  let Prev_ref: any = useRef()
  let Shi_ref: any = useRef()

  const [count, setCount] = useState(0)

  useEffect(()=>{
    Dev_ref.current.style = Dev[count % Dev.length]
    Prev_ref.current.style = Prev[count % Prev.length]
    Shi_ref.current.style = Shi[count % Shi.length]

    
  })

  useEffect(()=> {
    setInterval (()=>{
      setCount ((el) => el + 0.5)
    }, 3000)
  }, [])
 
  return(
    <Container>
      <Holder>
        <Develop ref = {Dev_ref} >Develop.</Develop>
        <Develop ref = {Prev_ref}>Preview.</Develop>
        <Develop ref = {Shi_ref}>Ship.</Develop>

 
      </Holder>
      <Card>Vercel's frontend cloud gives developers the frameworks, workflows,<br/>
           and infrastructure to build a faster, more personalized Web.
</Card>
        <Btn>
       <BtnHolder1>
        
        Start Deploying
       </BtnHolder1>

       <BtnHolder2> Get a Demo</BtnHolder2>
        </Btn>

        <Wrap>
          <DaysDiv>
            <Holds> {days} :</Holds>
            <Div>Days</Div>
          </DaysDiv>
          <DaysDiv>
            <Holds> {hours} :</Holds>
            <Div>Hours</Div>
          </DaysDiv>
          <DaysDiv>
            <Holds> {minutes} :</Holds>
            <Div>Minutes</Div>
          </DaysDiv>
          <DaysDiv>
            <Holds> {seconds} :</Holds>
            <Div>Seconds</Div>
          </DaysDiv>
        </Wrap>
    </Container>
  )
}
export default Hero

const Div = styled.div`
color: white;
font-size:20px;
`

const Holds = styled.div`
color: white;
font-size:25px;
`

const DaysDiv = styled.div`
display: flex;
flex-direction: column;
margin-left:25px;
align-items: center;
`


const Wrap= styled.div`
display: flex;
align-items: center;
justify-content: center;
width: 100%;
margin-top: 30px;
`

const BtnHolder2 = styled.div`
     width: 180px;
   height: 40px;
   background-color: #000000;
   margin-left: 10px;
   border-radius: 10px;
   padding-left: 90px;
   padding-top: 15px;
   font-weight: 300;
   color: white;
   border: 1px solid purple;
`

const BtnHolder1 = styled.div`
   width: 180px;
   height: 40px;
   background-color: white;
   border-radius: 10px;
   padding-left: 80px;
   padding-top: 15px;
   font-weight: 300;

   &:hover{
    background-color: #d1cece;
   }
`

const Btn = styled.div`
margin-top: 40px;
 display: flex;
 justify-content: center;
align-items: center;
`

const Card = styled.div`
text-align:center;
color:grey;
font-size: 25px;
`

const Develop = styled.h1`
color:white;
font-size:90px;
font-weight: 900;



`

const Holder = styled.div`
display: flex;
justify-content:center;
align-items: center;

`
const Container = styled.div`
width: 100%;
height: 80vh;
background-color: black;
// display: flex;
// justify-content: center;
// align-items: center;

`