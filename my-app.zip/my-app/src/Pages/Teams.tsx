import styled from "styled-components"
import pix from "../Assets/adobe.svg"
import pix2 from "../Assets/okta.svg"
import pix3 from "../Assets/under-armour.svg"
import pix4 from "../Assets/ebay.svg"
import pix5 from "../Assets/zapier.svg"
import pix6 from "../Assets/loom.svg"
import pix7 from "../Assets/hashicorp.svg"
import pix8 from "../Assets/tailwindcss.svg"
import pix9 from "../Assets/washingtonpost.svg" 

const Teams = () => {
    return (
        <div>
            <Container>
                <Wrap>
                    <Text>
                       TRUSTED BY THE BEST FRONTEND TEAMS.
                    </Text>
                </Wrap>
                <Wrapper>
                <Image src = {pix}/>
                <Image src = {pix2}/>
                <Image src = {pix3}/>
                <Image src = {pix4}/>
                <Image src = {pix5}/>
                </Wrapper>
                <Wrapper2>
                <Image2 src = {pix6}/>
                <Image2 src = {pix7}/>
                <Image2 src = {pix8}/>
                <Image2 src = {pix9}/>
                </Wrapper2>

            </Container>
        </div>
    )
}


export default Teams;

const Text = styled.div`
widht: 100%;
height: 100%;
background-color: black;
color: grey;
font-size: 15px;
letter-spacing: 0.4rem;

`
const Wrap = styled.div`
widht: 100%;
height: 10%;
background-color: black;
display: flex;
align-items: center;
justify-content: center;
`
const Image2 = styled.img`
width: 100px;
height: 70px;
background-color: white;

`

const Image = styled.img`
width: 80px;
height: 50px;
background-color: white;
`

const Wrapper2 = styled.div`
width: 100%;
height: 50%;
// background-color: green;
display: flex;
align-items: center;
justify-content: space-evenly;


`
const Wrapper = styled.div`
width: 100%;
height: 50%;
// background-color: blue;
display: flex;
align-items: center;
justify-content: space-evenly;

`

const Container = styled.div`
width: 100%;
height: 30vh;
background-color: black;
padding-bottom: 20px;
font-family: sans-serif;

`